chrome.runtime.onInstalled.addListener(() => {
  console.log('GTM Consent Extension Installed');
});

